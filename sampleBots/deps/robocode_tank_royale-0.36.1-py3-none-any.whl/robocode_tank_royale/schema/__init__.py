"""
Auto-generated __init__.py for schema types.
"""

from typing import Any, Type

from .won_round_event import WonRoundEvent
from .change_tps import ChangeTps
from .round_ended_event_for_bot import RoundEndedEventForBot
from .message import Message
from .game_ended_event_for_bot import GameEndedEventForBot
from .game_setup import GameSetup
from .pause_game import PauseGame
from .bullet_state import BulletState
from .bot_death_event import BotDeathEvent
from .round_started_event import RoundStartedEvent
from .participant import Participant
from .game_aborted_event import GameAbortedEvent
from .bullet_hit_bot_event import BulletHitBotEvent
from .color import Color
from .round_ended_event_for_observer import RoundEndedEventForObserver
from .bot_intent import BotIntent
from .hit_by_bullet_event import HitByBulletEvent
from .scanned_bot_event import ScannedBotEvent
from .game_paused_event_for_observer import GamePausedEventForObserver
from .bot_state import BotState
from .next_turn import NextTurn
from .bot_list_update import BotListUpdate
from .resume_game import ResumeGame
from .server_handshake import ServerHandshake
from .bot_hit_bot_event import BotHitBotEvent
from .bot_handshake import BotHandshake
from .tick_event_for_observer import TickEventForObserver
from .skipped_turn_event import SkippedTurnEvent
from .tick_event_for_bot import TickEventForBot
from .tps_changed_event import TpsChangedEvent
from .team_message_event import TeamMessageEvent
from .stop_game import StopGame
from .bot_state_with_id import BotStateWithId
from .event import Event
from .game_started_event_for_bot import GameStartedEventForBot
from .bullet_hit_bullet_event import BulletHitBulletEvent
from .results_for_observer import ResultsForObserver
from .bot_ready import BotReady
from .bullet_hit_wall_event import BulletHitWallEvent
from .bot_hit_wall_event import BotHitWallEvent
from .game_ended_event_for_observer import GameEndedEventForObserver
from .observer_handshake import ObserverHandshake
from .bullet_fired_event import BulletFiredEvent
from .bot_address import BotAddress
from .results_for_bot import ResultsForBot
from .controller_handshake import ControllerHandshake
from .bot_info import BotInfo
from .game_resumed_event_for_observer import GameResumedEventForObserver
from .team_message import TeamMessage
from .bot_policy_update import BotPolicyUpdate
from .start_game import StartGame
from .game_started_event_for_observer import GameStartedEventForObserver
from .initial_position import InitialPosition

__all__ = [
    "WonRoundEvent",
    "ChangeTps",
    "RoundEndedEventForBot",
    "Message",
    "GameEndedEventForBot",
    "GameSetup",
    "PauseGame",
    "BulletState",
    "BotDeathEvent",
    "RoundStartedEvent",
    "Participant",
    "GameAbortedEvent",
    "BulletHitBotEvent",
    "Color",
    "RoundEndedEventForObserver",
    "BotIntent",
    "HitByBulletEvent",
    "ScannedBotEvent",
    "GamePausedEventForObserver",
    "BotState",
    "NextTurn",
    "BotListUpdate",
    "ResumeGame",
    "ServerHandshake",
    "BotHitBotEvent",
    "BotHandshake",
    "TickEventForObserver",
    "SkippedTurnEvent",
    "TickEventForBot",
    "TpsChangedEvent",
    "TeamMessageEvent",
    "StopGame",
    "BotStateWithId",
    "Event",
    "GameStartedEventForBot",
    "BulletHitBulletEvent",
    "ResultsForObserver",
    "BotReady",
    "BulletHitWallEvent",
    "BotHitWallEvent",
    "GameEndedEventForObserver",
    "ObserverHandshake",
    "BulletFiredEvent",
    "BotAddress",
    "ResultsForBot",
    "ControllerHandshake",
    "BotInfo",
    "GameResumedEventForObserver",
    "TeamMessage",
    "BotPolicyUpdate",
    "StartGame",
    "GameStartedEventForObserver",
    "InitialPosition"
]

CLASS_MAP: dict[str, Type[Any]] = {
    "WonRoundEvent": WonRoundEvent,
    "ChangeTps": ChangeTps,
    "RoundEndedEventForBot": RoundEndedEventForBot,
    "Message": Message,
    "GameEndedEventForBot": GameEndedEventForBot,
    "GameSetup": GameSetup,
    "PauseGame": PauseGame,
    "BulletState": BulletState,
    "BotDeathEvent": BotDeathEvent,
    "RoundStartedEvent": RoundStartedEvent,
    "Participant": Participant,
    "GameAbortedEvent": GameAbortedEvent,
    "BulletHitBotEvent": BulletHitBotEvent,
    "Color": Color,
    "RoundEndedEventForObserver": RoundEndedEventForObserver,
    "BotIntent": BotIntent,
    "HitByBulletEvent": HitByBulletEvent,
    "ScannedBotEvent": ScannedBotEvent,
    "GamePausedEventForObserver": GamePausedEventForObserver,
    "BotState": BotState,
    "NextTurn": NextTurn,
    "BotListUpdate": BotListUpdate,
    "ResumeGame": ResumeGame,
    "ServerHandshake": ServerHandshake,
    "BotHitBotEvent": BotHitBotEvent,
    "BotHandshake": BotHandshake,
    "TickEventForObserver": TickEventForObserver,
    "SkippedTurnEvent": SkippedTurnEvent,
    "TickEventForBot": TickEventForBot,
    "TpsChangedEvent": TpsChangedEvent,
    "TeamMessageEvent": TeamMessageEvent,
    "StopGame": StopGame,
    "BotStateWithId": BotStateWithId,
    "Event": Event,
    "GameStartedEventForBot": GameStartedEventForBot,
    "BulletHitBulletEvent": BulletHitBulletEvent,
    "ResultsForObserver": ResultsForObserver,
    "BotReady": BotReady,
    "BulletHitWallEvent": BulletHitWallEvent,
    "BotHitWallEvent": BotHitWallEvent,
    "GameEndedEventForObserver": GameEndedEventForObserver,
    "ObserverHandshake": ObserverHandshake,
    "BulletFiredEvent": BulletFiredEvent,
    "BotAddress": BotAddress,
    "ResultsForBot": ResultsForBot,
    "ControllerHandshake": ControllerHandshake,
    "BotInfo": BotInfo,
    "GameResumedEventForObserver": GameResumedEventForObserver,
    "TeamMessage": TeamMessage,
    "BotPolicyUpdate": BotPolicyUpdate,
    "StartGame": StartGame,
    "GameStartedEventForObserver": GameStartedEventForObserver,
    "InitialPosition": InitialPosition,
}
